/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_java_swing_01;

/**
 *
 * @author carrizosam
 */
public class Ejercicio_java_swing_01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        registro frame = new registro ();
        frame.setVisible(true);
        frame.setSize(650,510);
    }
    
}
